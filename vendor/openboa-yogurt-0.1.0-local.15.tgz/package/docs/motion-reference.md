# Motion references

Research reviewed on 20 November 2026 for [component library revision 4](engineering/controls/component-library/spec.md#motion-and-visual-craft--local-follow-up-revision-4). The [motion inventory](../catalog/motion.json) assigns a treatment to all 125 components and 14 composition blocks. Each row gives the stable catalog ID, the proposed Yogurt treatment and the exact title of the closest published reference where relevant. A null title records a decision to preserve reading, geometry or direct input, or to use an operation-specific cue from the host. These assignments are design guidance. Implementation and interaction evidence belong to each renderer and revision. [Component craft and motion](component-quality.md) · [DesignBookmark Motion](https://designbookmark.com/motion)

## Apply the references

| Interaction | Published examples | Yogurt treatment |
| --- | --- | --- |
| Press and result | Command button, Copy button, Loading to success | Start feedback under the input and preserve the hit area and label width. Keep pending text within the same control and reflect the host’s result. A canceled action leaves the control available and fires zero actions. |
| Editing and direct manipulation | Springy input, OTP code, Number stepper, Range slider, File drop, Swipe deck | Keep caret, selection and pointer position coupled to the value. Restrict settling to a gesture’s released endpoint or a visual hint. Sliders and grips track the pointer throughout the drag and retain keyboard operation. |
| Choice and navigation | Toggle switch, Tab pill, Segmented control, Pagination dots, Step progress, Sidebar collapse | The actual selection, accessible state and displayed content change together. A visual indicator can travel within its container and retarget on reversal. A rail opens from its real edge and keeps the current destination and reading position. |
| Anchored and modal layers | Spring dropdown, Morph tooltip, Dynamic menu, Command palette, Expand card | Use a short anchored reveal for the layer or detail. Preserve scroll and reading position around it. Focus arrives on open and returns on dismiss. The content remains readable throughout the transition. |
| Conversation and operations | Prompt box, Streaming reply, Mention picker, Agent steps, Voice input, Avatar motion system | Keep input, saved drafts and transcript position stable. Make every running cue depend on host state and distinguish waiting, blocked and finished in text. Use gaze-led movement on the original Yogurt silhouette and keep the outer layout stable. |
| Toasts and attention | Notification stack, Marker text, Invite people | Acknowledge resolved events in their own place. Keep the toast readable, make dismissal predictable and keep membership or other source facts steady while an action is pending. |

The earlier gallery rehearsal recorded **Spring dropdown**, **Segmented control** and **Loading to success** interactions. The rest of this comparison draws on the current published catalog and the credited creator pages for **Agent steps**, **Voice input**, **Notification stack** and **Marker text**. The treatments use OpenBoa’s geometry, palette and motion values. [Gallery rehearsal](component-quality.md#reference-interactions) · [DesignBookmark Motion](https://designbookmark.com/motion) · [Kokonut UI agent steps](https://kokonutui.com/docs/ai/ai-loading) · [Kokonut UI voice input](https://kokonutui.com/docs/ai/ai-voice) · [Kokonut UI notification stack](https://kokonutui.com/docs/cards/notification-stack) · [Kokonut UI marker text](https://kokonutui.com/docs/texts/marker-text) · [Grok Bot presence](https://x.ai/news/designing-grok-bot#presence-as-interface)

## Grok Bot beyond the design article

| Source | Evidence | Yogurt decision |
| --- | --- | --- |
| [Designing Grok Bot](https://x.ai/news/designing-grok-bot#presence-as-interface) | The design account describes six states and the use of character eyes as a persistent, legible signal. | Keep Kai and Sol's own outline, palette and recessed edge. Use position and eyelid height to carry state. |
| [Grok Bot product changelog](https://x.ai/changelog/bot) | The changelog documents an animated avatar alone in a working direct chat, an acknowledgment before longer work, a separate upload meter and a later revision of eye size. | In the active transcript, use a compact working cue. Keep upload progress and approval content as distinct controls. Maintain recognizable proportions at roster scale. |
| [Grok Bot 1.0 launch](https://x.ai/news/grok-bot-1-0) and its [launch film scene index](https://launchscene.app/v/xai-grok-bot-introducing-grok-bot-1-0-ai-teammates-that-work?play=1&s=10) | The call vignette around 0:07–0:19 distinguishes a waveform from the avatar's blink. A meeting tile shows how a small avatar can coexist with other participants. This is evidence about the launch film. | Express voice with the voice controls, labels and any host-supplied metering. Keep the avatar focused on identity and work state in the base component. |
| [Grok Bot Galaxy sessions](https://x.ai/galaxy) and [beta launch examples](https://x.ai/news/introducing-grok-bot) | These public sources cover engineering, operations and team workflows with tool activity and review handoffs. | Distinguish active work from a request for a human. Keep approvals inspectable and motion independent of whether the host effects succeed. |
| [Mobile guide](https://docs.x.ai/grok-bot/mobile) and [conversation guide](https://docs.x.ai/grok-bot/chat-and-collaboration) | The guides document draft cards in the thread, voice chats, dictation and changes that can be initiated while the agent works. | Keep the avatar small on narrow screens. Treat voice, draft review and agent presence as independent inputs. Keep historical messages stationary. |

Yogurt's timings are authored in [the presence motion source](../assets/agents/presence-motion.json). The sources establish interaction intent. Runtime timing, parity and accessibility require observation in Yogurt.

## Grok Bot eye motion observed frame by frame

The public interactive demo was sampled in a browser at roughly 33 ms intervals while its six tabs were selected manually, with the automatic lifecycle tour stopped. Measurements below describe the public demo's SVG view box. The launch films were sampled independently at known video timestamps.

| Surface | Observed motion | Design choice in Yogurt |
| --- | --- | --- |
| Idle | In an 8.4-second sample, the eye centers held their position. Late in the sample one eye narrowed nearly shut while the other held its tall shape. Most of the cycle was quiet. | Keep a long rest. Insert one small glance, a staggered lid close, a fully closed beat and a return to center. |
| Working | After the entry gesture, two readable holds put the eyes at about (146, 96) and (86, 128) in the demo. The scan moved diagonally between those holds. Around three seconds the two eye heights dropped to about one fifth of their open size and came back. Several frames show one eye closing ahead of the other. | Use a wider diagonal scan with pauses at its endpoints. Drive each eyelid independently and hold both at zero briefly before reopening. |
| Waiting | The eye centers settled after the entry and stayed nearly fixed. Their width and height separated into a distinctly broad, low shape. | A short downward glance and wider, calmer eyes communicate a held state. |
| Thinking and blocked | The public demo settled into three moving dots for Thinking and an exclamation for Blocked. | Keep each agent visible. Thinking directs the eyes up and away. Blocked briefly closes both eyes and holds a low, narrowed gaze. |
| Finished | The demo uses a much stronger change in aperture with eyes appearing and disappearing independently during the celebration. | Hold a complete closure for about 140 ms within a short finishing gesture, then open and center. |
| Meeting tile and team chat | The 1.0 film shows tall eyes at 15.5s, short eyes near 16.0s and tall eyes again at 16.5s in the meeting tile. The eyes tilt or change shape around 17.5–18.5s. The Team Bots film shows a compact working face beside text around 13s. | Make the blink legible in both roster and larger samples. Keep the work label available beside the animated face. |

[Public avatar demo](https://x.ai/news/designing-grok-bot#what-are-they-doing) · [Grok Bot 1.0 film](https://whatships.com/videos/grok-bot-1/) · [Team Bots film](https://whatships.com/videos/team-bots/) · [Official beta film](https://www.youtube.com/watch?v=F1_0Lkp16Rc)

The revision 5 Yogurt frame includes progress through the clip, horizontal and vertical gaze, two independent lid heights and one eye width. Both renderers share the same source. The working scan has 21 view-box units of horizontal travel. The ready tick runs every 5.1 seconds when visible. Its open neutral pose matches the original artwork. Archived portraits and the system's reduced-motion preference use that pose.

## OpenBot and Codex implementation references

- **nightly-labs OpenBot.** The brand module maps work status to avatar expression. The mobile component controls whether the renderer runs using focus, connection and animation preferences. Yogurt uses one portable presence source and pauses the two repeating states outside the visible web area. A Zig host can schedule the next changing frame and skip held poses. [Avatar state mapping](https://github.com/nightly-labs/openbot/blob/8fc29851e68976b5d408fda0aeaf5d60f3826326/packages/brand/src/bloub-avatar-motion.ts) · [Mobile avatar renderer](https://github.com/nightly-labs/openbot/blob/8fc29851e68976b5d408fda0aeaf5d60f3826326/apps/mobile/src/features/agents/components/bloub-avatar.tsx)
- **CopilotKit OpenBot.** A shared timing module feeds view transitions. Its detail pane varies travel with the system preference while navigation remains owned by the caller. Yogurt's layers and control movement use the same role and timing source. [Shared timing](https://github.com/CopilotKit/OpenBot/blob/7b1cf330a4e8ce985afc3965a8a8e7a5f21aa5a8/app/src/lib/motion.ts) · [Responsive detail pane](https://github.com/CopilotKit/OpenBot/blob/7b1cf330a4e8ce985afc3965a8a8e7a5f21aa5a8/app/src/components/layout/detail-panel.tsx)
- **Codex TUI.** The public Rust source schedules visible loading frames from elapsed time and supplies a static reduced-motion representation. Its live status row avoids displacing the composer. In Yogurt, Zig hosts pass elapsed time and the motion preference to the frame selector. The active transcript cue is separate from recorded messages. [Motion primitives](https://github.com/openai/codex/blob/45ace810b3d394f177fb6b1c8a10db9c698e6e05/codex-rs/tui/src/motion.rs) · [Live status row](https://github.com/openai/codex/blob/45ace810b3d394f177fb6b1c8a10db9c698e6e05/codex-rs/tui/src/status_indicator_widget.rs)

## Compose and verify

- **Agent workspace.** Keep the agent roster readable while the selected agent, thread and computer preview change. The original open silhouette tilts after each glance while the visible state text stays in sync with the host. Ready holds its stance through a double blink. Thinking makes a small centered turn as the eyes travel around the face. Working repeats a scan and reads across a lower line. Waiting, blocked and finished settle into distinct poses. Reduced motion uses the centered eyes and keeps the state label. [Grok Bot presence](https://x.ai/news/designing-grok-bot#presence-as-interface)
- **Project workspace.** Compose from navigation, transcript and detail layers. Preserve the active project, scroll and return focus when the sidebar or an inspector changes. Keep project marks, receipts, metrics and previously read copy stable. [Component library revision 4](engineering/controls/component-library/spec.md#motion-and-visual-craft--local-follow-up-revision-4)
- **Interaction evidence.** For each implementation under review, observe rest, input, first change, mid-transition, settle and dismissal. Repeat with rapid reversal, alternate input and reduced motion. Check actual focus and callback count alongside visual evidence. For static rows, verify readability, alignment, semantics and reflow. A native host needs its own runtime observation. [Component craft rubric](component-quality.md#review-the-frames-a-person-actually-sees) · [StageShow rehearsal](https://github.com/benjitaylor/skills/blob/main/stageshow/references/rehearse.md)


## Eye and body motion

The current avatar uses [six authored clips](../assets/agents/avatar-motion.json) for its body and two eyes. Direction, posture and rhythm distinguish the states.

| State | Timing and gesture |
| --- | --- |
| Ready | An 11.16-second loop holds its stance, gives a soft double blink, then checks one side and later the other. |
| Thinking | Over 5.64 seconds the eyes pause overhead, travel to the right edge, disappear during a centered turn, and return from the left. A brief squint leads into a slightly asymmetric upward look. |
| Working | In a 6.16-second loop the round eyes read in quick passes with short resets to the start of each line. The body stays low and close to level as it follows the eyes across. |
| Waiting | In a 6.42-second loop the wide-open eyes lead the body as it slides and leans to the left and then to the right. Each side holds for just over a second before the character blinks and looks ahead. |
| Blocked | Over 4.32 seconds a short flinch gives way to a droop, followed by a slower second sink and a long hold. The two X eyes appear during the first drop and stay low. |
| Finished | Over 4.27 seconds a taller spring and a smaller rebound share a distinct landing between them. A closed-eye frame leads into two rounded arches with the stroke weight of the Blocked eyes. The arches rise at both peaks and move with the sway at the same weight. |

Waiting uses the widest roll and Thinking holds the highest gaze. Blocked settles low, and Finished compresses at the launch and landing of each jump. Kai moves slightly more than Sol. Both have a restrained scale at 32 points and below. A state change blends for 112 ms from the pose already displayed. Reduced motion holds a representative body and face pose and preserves the state label. The original open pair is used for archived portraits.

Grok Bot's public demonstration informed the delayed body response, independent eyes and reuse of the outline. OpenBot's desktop and mobile lifecycles informed suspension and reuse. The web implementation delegates interpolation to Web Animations. Zig samples the same numerical poses and reuses stable path data. [Grok Bot animation study](https://x.ai/news/designing-grok-bot#what-are-they-doing) · [OpenBot desktop visibility](https://github.com/nightly-labs/openbot/blob/8fc29851e68976b5d408fda0aeaf5d60f3826326/packages/ui/src/features/agents/AgentAvatar.tsx) · [OpenBot mobile pose cache](https://github.com/nightly-labs/openbot/blob/8fc29851e68976b5d408fda0aeaf5d60f3826326/apps/mobile/src/features/agents/model/plush/plush-frames.ts) · [Yogurt motion specification](engineering/controls/component-library/spec.md#eye-and-body-acting--local-follow-up-revision-6)


## Agent family

[Open the family gallery](../agents.html) to play the same six performances across fifteen silhouettes and forty-five fitted notches. Select a silhouette to see all of its notch placements at 96 px. The roster renders every placement at 24 px. The shared palette provides 26 fill options with at least 4.5:1 eye contrast.

The [SVG inventory](../assets/agents/silhouettes.json) defines each outline and its eye center. [Animation fits](../assets/agents/animation-fits.json) set travel, tilt and gaze ranges for each silhouette. The fit reuses the same durations, motion curves, eye outlines and phase boundaries across notch positions and colors. Kai and Sol keep their existing authored profiles.

Use a registered shape-and-notch ID such as `round-star-right`. The 1,170 geometry and color combinations are renderable candidates. An identity counts toward assignment only after the palette review confirms it is distinguishable at roster size.
