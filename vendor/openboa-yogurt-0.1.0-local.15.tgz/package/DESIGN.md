# Design with yogurt

Read the [brand contract](catalog/brand.json) for the canonical artwork, English vocabulary, palette and role sources. Use the same [component entry](docs/using-yogurt.md) in web and Zig product intents.

Start with the thing a person came to do. A project supplies the facts and actions it can actually support. Yogurt supplies the layout, wording, interaction and evidence for presenting them. [Try two product briefs](playbook.html) · [Repository and distribution design](docs/repository.md)

For the shared visual direction, component choices and quality standard, use the [design handbook](docs/index.html). To change a shared rule or renderer, follow the owning [intent and engineering spec](docs/README.md).

## Compose screens

Start with shared Yogurt tokens and basic components. Combine them in the project to suit its tasks, information and navigation. The project owns its content, route state and actions.

Use an editable preset when a common combination fits. An installed preset stays in the project, imports the same basic components and can be adapted alongside the other project views.

When several projects arrive at the same behavior, compare their inputs, states and recovery paths. Lift the common behavior into a shared component or preset when it supports the real uses in each project. Keep workspace-specific facts and actions with their owner. [Required design system rules](docs/design-system-rules.md) · [Sidebar example](docs/sidebar.md) · [Component entries](docs/components.md)

## Find the task

| The person wants to… | Open this pattern |
| --- | --- |
| Find one item in a collection | `pattern.find-records` |
| Understand a record, its source and how current it is | `pattern.inspect-record` |
| Make a decision that changes something | `pattern.review-decision` |
| Find out what happened after a command was sent | `pattern.track-request` |

Run `node scripts/describe-pattern.mjs --list` from this kit. For example, `node scripts/describe-pattern.mjs pattern.review-decision web` returns the product inputs, parts, state rules, copy, keyboard behavior, acceptance examples and available target implementation. The same records are readable as JSON. The project keeps its intent in its usual place. Record the chosen pattern IDs and the product evidence alongside that intent. [Pattern catalog](catalog/patterns.json)

## Carry the identity into a screen

- Use the Upright 9 company symbol and its B2 signature where the company signs a surface. The Rethink Sans family serves every text role. Keep the outlined 760 wordmark for the company nameplate. The food marks identify projects. A named agent uses its own face and silhouette. [Identity](index.html#logo) · [Sources](library.html)
- Start from the Upright 9 symbol’s Ink blue, `slate.750` (#175174), for the main action on paper. Take hue and lightness from the single numbered palette. A component may give an existing token a role for text, focus or a surface. Keep the base palette common to UI, charts, emoji and agents. Use a word or shape with a state color. [Tokens](tokens/brand.json) · [Color in context](system.html#color)
- Keep a product screen quiet enough to read at a glance. Give one consequence the primary action, keep supporting facts near the decision and put secondary detail behind a disclosure when it can wait. Use the existing control and touch dimensions. [Controls and dimensions](system.html#controls)
- Write English product copy. Name the object and next action. A pending request can say “Request sent.” A verified result can name the effect. Keep the light touch for brand and project descriptions. Errors and permission messages should help someone recover. [Voice](index.html#voice) · [Terms](content/terms.json)
- Use a short transition to explain a change of position or visibility. Respect reduced motion and keep the final state and focus legible. Agent eye motion is an identity study. [Motion](library.html#motion)

## Match the target

Start an app client on Vercel Native SDK, the selected default. Use Next.js or Vite for a web surface and declare any embedded WebView explicitly. [Native stack decision](docs/native-stack.md)

A Web CSS entry gives a class and semantic HTML. A web example gives a runnable local specimen. A guide example illustrates state choices with invented facts. A contract describes the intended behavior. The catalog records availability for each target. If the needed adapter is missing, record the gap and the proposed owner. A project may deliver a reviewed local implementation under its own name and evidence.

For a production dependency resolve the owning project’s accepted release and target. The local SDK contains typed web exports and native templates. A production release requires the consuming project’s chosen pin and target checks. [Current web inputs](system.html#handoff) · [Adoption](adoption.html)
