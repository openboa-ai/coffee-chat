# Web adapter

Each component has a typed `@openboa/yogurt/<id>` entry. Load `@openboa/yogurt/styles.css` once and wrap the application in `Yogurt`. The local shadcn items and Yogurt CLI install editable entries. [Installation](../../docs/using-yogurt.md) · [Catalog](../../components.html)
