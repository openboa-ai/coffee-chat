# Reference coverage

The 20 November 2026 snapshot maps the public shadcn/ui Components guide and registry, TDS Mobile and TDS React Native to the working Yogurt catalog. Each link opens a real component. A variant can change the interaction while retaining one import. The TDS indexes include anatomy guides and a retired list-row migration entry. The source row count includes those pages.

The separate shadcn AI Elements collection has its own index. TDS React Native informs the design of OpenBoa applications. OpenBoa ships its native implementation for the Vercel Native SDK.

[Browse the library](../components.html) · [Install and use Yogurt](using-yogurt.md) · [Machine-readable crosswalk](../catalog/references.json)

## shadcn/ui

| Public reference | Yogurt component | Variant |
| --- | --- | --- |
| [Accordion](https://ui.shadcn.com/docs/components/base/accordion) | [Accordion](../components.html#accordion) | Default |
| [Alert](https://ui.shadcn.com/docs/components/base/alert) | [Notice](../components.html#notice) | Default |
| [Alert Dialog](https://ui.shadcn.com/docs/components/base/alert-dialog) | [ConfirmDialog](../components.html#confirm-dialog) | Default |
| [Aspect Ratio](https://ui.shadcn.com/docs/components/base/aspect-ratio) | [AspectRatio](../components.html#aspect-ratio) | Default |
| [Attachment](https://ui.shadcn.com/docs/components/base/attachment) | [Attachment](../components.html#attachment) | Default |
| [Avatar](https://ui.shadcn.com/docs/components/base/avatar) | [Avatar](../components.html#avatar) | Default |
| [Badge](https://ui.shadcn.com/docs/components/base/badge) | [Badge](../components.html#badge) | Default |
| [Breadcrumb](https://ui.shadcn.com/docs/components/base/breadcrumb) | [Breadcrumb](../components.html#breadcrumb) | Default |
| [Bubble](https://ui.shadcn.com/docs/components/base/bubble) | [Bubble](../components.html#bubble) | Default |
| [Button](https://ui.shadcn.com/docs/components/base/button) | [Button](../components.html#button) | Default |
| [Button Group](https://ui.shadcn.com/docs/components/base/button-group) | [ButtonGroup](../components.html#button-group) | Default |
| [Calendar](https://ui.shadcn.com/docs/components/base/calendar) | [Calendar](../components.html#calendar) | Default |
| [Card](https://ui.shadcn.com/docs/components/base/card) | [Card](../components.html#card) | Default |
| [Carousel](https://ui.shadcn.com/docs/components/base/carousel) | [Carousel](../components.html#carousel) | Default |
| [Chart](https://ui.shadcn.com/docs/components/base/chart) | [Chart](../components.html#chart) | Default |
| [Checkbox](https://ui.shadcn.com/docs/components/base/checkbox) | [Checkbox](../components.html#checkbox) | Default |
| [Code Block](https://ui.shadcn.com/docs/components/base/code-block) | [CodeBlock](../components.html#code-block) | Default |
| [Collapsible](https://ui.shadcn.com/docs/components/base/collapsible) | [DisclosureRow](../components.html#disclosure-row) | Default |
| [Combobox](https://ui.shadcn.com/docs/components/base/combobox) | [Combobox](../components.html#combobox) | Default |
| [Command](https://ui.shadcn.com/docs/components/base/command) | [Command](../components.html#command) | Default |
| [Context Menu](https://ui.shadcn.com/docs/components/base/context-menu) | [ContextMenu](../components.html#context-menu) | Default |
| [Data Table](https://ui.shadcn.com/docs/components/base/data-table) | [DataTable](../components.html#data-table) | Default |
| [Date Picker](https://ui.shadcn.com/docs/components/base/date-picker) | [DatePicker](../components.html#date-picker) | Default |
| [Dialog](https://ui.shadcn.com/docs/components/base/dialog) | [Dialog](../components.html#dialog) | Default |
| [Direction](https://ui.shadcn.com/docs/components/base/direction) | [Direction](../components.html#direction) | Default |
| [Drawer](https://ui.shadcn.com/docs/components/base/drawer) | [Drawer](../components.html#drawer) | Default |
| [Dropdown Menu](https://ui.shadcn.com/docs/components/base/dropdown-menu) | [ActionMenu](../components.html#action-menu) | Default |
| [Empty](https://ui.shadcn.com/docs/components/base/empty) | [EmptyResult](../components.html#empty-result) | Default |
| [Field](https://ui.shadcn.com/docs/components/base/field) | [Field](../components.html#field) | Default |
| [Hover Card](https://ui.shadcn.com/docs/components/base/hover-card) | [HoverCard](../components.html#hover-card) | Default |
| [Input](https://ui.shadcn.com/docs/components/base/input) | [TextField](../components.html#text-field) | Default |
| [Input Group](https://ui.shadcn.com/docs/components/base/input-group) | [InputGroup](../components.html#input-group) | Default |
| [Input Otp](https://ui.shadcn.com/docs/components/base/input-otp) | [InputOTP](../components.html#input-otp) | Default |
| [Item](https://ui.shadcn.com/docs/components/base/item) | [ListRow](../components.html#list-row) | Default |
| [Kbd](https://ui.shadcn.com/docs/components/base/kbd) | [KeyboardShortcut](../components.html#kbd) | Default |
| [Label](https://ui.shadcn.com/docs/components/base/label) | [Label](../components.html#label) | Default |
| [Marker](https://ui.shadcn.com/docs/components/base/marker) | [Marker](../components.html#marker) | Default |
| [Menubar](https://ui.shadcn.com/docs/components/base/menubar) | [Menubar](../components.html#menubar) | Default |
| [Message](https://ui.shadcn.com/docs/components/base/message) | [Message](../components.html#message) | Default |
| [Message Scroller](https://ui.shadcn.com/docs/components/base/message-scroller) | [Transcript](../components.html#transcript) | Default |
| [Native Select](https://ui.shadcn.com/docs/components/base/native-select) | [Select](../components.html#select) | Default |
| [Navigation Menu](https://ui.shadcn.com/docs/components/base/navigation-menu) | [NavigationMenu](../components.html#navigation-menu) | Default |
| [Pagination](https://ui.shadcn.com/docs/components/base/pagination) | [Pagination](../components.html#pagination) | Default |
| [Popover](https://ui.shadcn.com/docs/components/base/popover) | [Popover](../components.html#popover) | Default |
| [Progress](https://ui.shadcn.com/docs/components/base/progress) | [Progress](../components.html#progress) | Default |
| [Questionnaire](https://ui.shadcn.com/docs/components/base/questionnaire) | [Questionnaire](../components.html#questionnaire) | Default |
| [Radio Group](https://ui.shadcn.com/docs/components/base/radio-group) | [RadioGroup](../components.html#radio-group) | Default |
| [Resizable](https://ui.shadcn.com/docs/components/base/resizable) | [Resizable](../components.html#resizable) | Default |
| [Scroll Area](https://ui.shadcn.com/docs/components/base/scroll-area) | [ScrollArea](../components.html#scroll-area) | Default |
| [Select](https://ui.shadcn.com/docs/components/base/select) | [Select](../components.html#select) | Default |
| [Separator](https://ui.shadcn.com/docs/components/base/separator) | [Divider](../components.html#divider) | Default |
| [Sheet](https://ui.shadcn.com/docs/components/base/sheet) | [Sheet](../components.html#sheet) | Default |
| [Sidebar](https://ui.shadcn.com/docs/components/base/sidebar) | [Sidebar](../components.html#sidebar) | Default |
| [Skeleton](https://ui.shadcn.com/docs/components/base/skeleton) | [Skeleton](../components.html#skeleton) | Default |
| [Slider](https://ui.shadcn.com/docs/components/base/slider) | [Slider](../components.html#slider) | Default |
| [Spinner](https://ui.shadcn.com/docs/components/base/spinner) | [Spinner](../components.html#spinner) | Default |
| [Switch](https://ui.shadcn.com/docs/components/base/switch) | [Switch](../components.html#switch) | Default |
| [Table](https://ui.shadcn.com/docs/components/base/table) | [Table](../components.html#table) | Default |
| [Tabs](https://ui.shadcn.com/docs/components/base/tabs) | [Tabs](../components.html#tabs) | Default |
| [Textarea](https://ui.shadcn.com/docs/components/base/textarea) | [Textarea](../components.html#textarea) | Default |
| [Toast](https://ui.shadcn.com/docs/components/base/toast) | [Toast](../components.html#toast) | Default |
| [Toggle](https://ui.shadcn.com/docs/components/base/toggle) | [Toggle](../components.html#toggle) | Default |
| [Toggle Group](https://ui.shadcn.com/docs/components/base/toggle-group) | [ToggleGroup](../components.html#toggle-group) | Default |
| [Tooltip](https://ui.shadcn.com/docs/components/base/tooltip) | [Tooltip](../components.html#tooltip) | Default |
| [Trace](https://ui.shadcn.com/docs/components/base/trace) | [Trace](../components.html#trace) | Default |
| [Typography](https://ui.shadcn.com/docs/components/base/typography) | [Text](../components.html#text) | Default |

## shadcn/ui registry

| Public reference | Yogurt component | Variant |
| --- | --- | --- |
| [Form](https://ui.shadcn.com/r/styles/base-nova/form.json) | [Form](../components.html#form) | Default |
| [Sonner](https://ui.shadcn.com/r/styles/base-nova/sonner.json) | [ToastStack](../components.html#toast-stack) | Default |

## TDS Mobile

| Public reference | Yogurt component | Variant |
| --- | --- | --- |
| [Badge](https://tossmini-docs.toss.im/tds-mobile/components/badge/) | [Badge](../components.html#badge) | Default |
| [Board Row](https://tossmini-docs.toss.im/tds-mobile/components/board-row/) | [Accordion](../components.html#accordion) | Default |
| [Border](https://tossmini-docs.toss.im/tds-mobile/components/border/) | [Divider](../components.html#divider) | Default |
| [Bottom Info](https://tossmini-docs.toss.im/tds-mobile/components/bottom-info/) | [BottomInfo](../components.html#bottom-info) | Default |
| [Bottom Sheet](https://tossmini-docs.toss.im/tds-mobile/components/bottom-sheet/) | [Drawer](../components.html#drawer) | Default |
| [Bubble](https://tossmini-docs.toss.im/tds-mobile/components/bubble/) | [Bubble](../components.html#bubble) | Default |
| [Button](https://tossmini-docs.toss.im/tds-mobile/components/button/) | [Button](../components.html#button) | Default |
| [Checkbox](https://tossmini-docs.toss.im/tds-mobile/components/checkbox/) | [Checkbox](../components.html#checkbox) | Default |
| [Grid List](https://tossmini-docs.toss.im/tds-mobile/components/grid-list/) | [GridList](../components.html#grid-list) | Default |
| [Highlight](https://tossmini-docs.toss.im/tds-mobile/components/highlight/) | [Highlight](../components.html#highlight) | Default |
| [Icon Button](https://tossmini-docs.toss.im/tds-mobile/components/icon-button/) | [IconButton](../components.html#icon-button) | Default |
| [List Footer](https://tossmini-docs.toss.im/tds-mobile/components/list-footer/) | [ListFooter](../components.html#list-footer) | Default |
| [List Header](https://tossmini-docs.toss.im/tds-mobile/components/list-header/) | [ListHeader](../components.html#list-header) | Default |
| [Loader](https://tossmini-docs.toss.im/tds-mobile/components/loader/) | [Spinner](../components.html#spinner) | Default |
| [Menu](https://tossmini-docs.toss.im/tds-mobile/components/menu/) | [ActionMenu](../components.html#action-menu) | Default |
| [Modal](https://tossmini-docs.toss.im/tds-mobile/components/modal/) | [Dialog](../components.html#dialog) | Default |
| [Numeric Spinner](https://tossmini-docs.toss.im/tds-mobile/components/numeric-spinner/) | [NumericSpinner](../components.html#numeric-spinner) | Default |
| [Paragraph](https://tossmini-docs.toss.im/tds-mobile/components/paragraph/) | [Text](../components.html#text) | Default |
| [Post](https://tossmini-docs.toss.im/tds-mobile/components/post/) | [Post](../components.html#post) | Default |
| [Progress Bar](https://tossmini-docs.toss.im/tds-mobile/components/progress-bar/) | [Progress](../components.html#progress) | Default |
| [Progress Stepper](https://tossmini-docs.toss.im/tds-mobile/components/progress-stepper/) | [Stepper](../components.html#stepper) | progress |
| [Rating](https://tossmini-docs.toss.im/tds-mobile/components/rating/) | [Rating](../components.html#rating) | Default |
| [Result](https://tossmini-docs.toss.im/tds-mobile/components/result/) | [Result](../components.html#result) | Default |
| [Search Field](https://tossmini-docs.toss.im/tds-mobile/components/search-field/) | [SearchField](../components.html#search-field) | Default |
| [Segmented Control](https://tossmini-docs.toss.im/tds-mobile/components/segmented-control/) | [SegmentedControl](../components.html#segmented-control) | Default |
| [Skeleton](https://tossmini-docs.toss.im/tds-mobile/components/skeleton/) | [Skeleton](../components.html#skeleton) | Default |
| [Slider](https://tossmini-docs.toss.im/tds-mobile/components/slider/) | [Slider](../components.html#slider) | Default |
| [Stepper](https://tossmini-docs.toss.im/tds-mobile/components/stepper/) | [Stepper](../components.html#stepper) | Default |
| [Switch](https://tossmini-docs.toss.im/tds-mobile/components/switch/) | [Switch](../components.html#switch) | Default |
| [Tab](https://tossmini-docs.toss.im/tds-mobile/components/tab/) | [Tabs](../components.html#tabs) | Default |
| [Table Row](https://tossmini-docs.toss.im/tds-mobile/components/table-row/) | [TableRow](../components.html#table-row) | Default |
| [Text Button](https://tossmini-docs.toss.im/tds-mobile/components/text-button/) | [Button](../components.html#button) | quiet |
| [Toast](https://tossmini-docs.toss.im/tds-mobile/components/toast/) | [Toast](../components.html#toast) | Default |
| [Tooltip](https://tossmini-docs.toss.im/tds-mobile/components/tooltip/) | [Tooltip](../components.html#tooltip) | Default |
| [Top](https://tossmini-docs.toss.im/tds-mobile/components/top/) | [PageHeader](../components.html#top) | Default |
| [Agreement v3](https://tossmini-docs.toss.im/tds-mobile/components/Agreement/v3/) | [Agreement](../components.html#agreement) | group |
| [Agreement v4](https://tossmini-docs.toss.im/tds-mobile/components/Agreement/v4/) | [Agreement](../components.html#agreement) | group |
| [Asset overview](https://tossmini-docs.toss.im/tds-mobile/components/Asset/check-first/) | [Asset](../components.html#asset) | Default |
| [Asset frame](https://tossmini-docs.toss.im/tds-mobile/components/Asset/frame/) | [Asset](../components.html#asset) | frame |
| [Asset media](https://tossmini-docs.toss.im/tds-mobile/components/Asset/asset/) | [Asset](../components.html#asset) | media |
| [Bottom CTA overview](https://tossmini-docs.toss.im/tds-mobile/components/BottomCTA/check-first/) | [BottomAction](../components.html#bottom-action) | Default |
| [Bottom CTA single](https://tossmini-docs.toss.im/tds-mobile/components/BottomCTA/Single/) | [BottomAction](../components.html#bottom-action) | single |
| [Bottom CTA double](https://tossmini-docs.toss.im/tds-mobile/components/BottomCTA/Double/) | [BottomAction](../components.html#bottom-action) | double |
| [FixedBottomCTA](https://tossmini-docs.toss.im/tds-mobile/components/BottomCTA/fixed-bottom-cta/) | [BottomAction](../components.html#bottom-action) | fixed |
| [Bar Chart](https://tossmini-docs.toss.im/tds-mobile/components/Chart/bar-chart/) | [BarChart](../components.html#bar-chart) | Default |
| [Dialog overview](https://tossmini-docs.toss.im/tds-mobile/components/Dialog/dialog/) | [Dialog](../components.html#dialog) | Default |
| [AlertDialog](https://tossmini-docs.toss.im/tds-mobile/components/Dialog/alert-dialog/) | [Dialog](../components.html#dialog) | acknowledge |
| [ConfirmDialog](https://tossmini-docs.toss.im/tds-mobile/components/Dialog/confirm-dialog/) | [ConfirmDialog](../components.html#confirm-dialog) | Default |
| [Alphabet Keypad](https://tossmini-docs.toss.im/tds-mobile/components/Keypad/alphabet-keypad/) | [Keypad](../components.html#keypad) | alphabet |
| [Full Secure Keypad](https://tossmini-docs.toss.im/tds-mobile/components/Keypad/full-secure-keypad/) | [Keypad](../components.html#keypad) | private |
| [Number Keypad](https://tossmini-docs.toss.im/tds-mobile/components/Keypad/number-keypad/) | [Keypad](../components.html#keypad) | number |
| [List row overview](https://tossmini-docs.toss.im/tds-mobile/components/ListRow/list-row-overview/) | [ListRow](../components.html#list-row) | Default |
| [List row anatomy](https://tossmini-docs.toss.im/tds-mobile/components/ListRow/list-row-components/) | [ListRow](../components.html#list-row) | Default |
| [Legacy list row replacement](https://tossmini-docs.toss.im/tds-mobile/components/ListRow/ListRowLegacy/list-row-legacy/) | [ListRow](../components.html#list-row) | replacement |
| [TextField](https://tossmini-docs.toss.im/tds-mobile/components/TextField/text-field/) | [TextField](../components.html#text-field) | Default |
| [SplitTextField](https://tossmini-docs.toss.im/tds-mobile/components/TextField/split-text-field/) | [SplitTextField](../components.html#split-text-field) | Default |
| [TextArea](https://tossmini-docs.toss.im/tds-mobile/components/TextField/text-area/) | [Textarea](../components.html#textarea) | Default |

## TDS React Native

| Public reference | Yogurt component | Variant |
| --- | --- | --- |
| [Amount Top](https://tossmini-docs.toss.im/tds-react-native/components/amount-top/) | [AmountTop](../components.html#amount-top) | Default |
| [Asset](https://tossmini-docs.toss.im/tds-react-native/components/asset/) | [Asset](../components.html#asset) | Default |
| [Badge](https://tossmini-docs.toss.im/tds-react-native/components/badge/) | [Badge](../components.html#badge) | Default |
| [Board Row](https://tossmini-docs.toss.im/tds-react-native/components/board-row/) | [Accordion](../components.html#accordion) | Default |
| [Border](https://tossmini-docs.toss.im/tds-react-native/components/border/) | [Divider](../components.html#divider) | Default |
| [Bottom Info](https://tossmini-docs.toss.im/tds-react-native/components/bottom-info/) | [BottomInfo](../components.html#bottom-info) | Default |
| [Button](https://tossmini-docs.toss.im/tds-react-native/components/button/) | [Button](../components.html#button) | Default |
| [Carousel](https://tossmini-docs.toss.im/tds-react-native/components/carousel/) | [Carousel](../components.html#carousel) | Default |
| [Checkbox](https://tossmini-docs.toss.im/tds-react-native/components/checkbox/) | [Checkbox](../components.html#checkbox) | Default |
| [Dialog](https://tossmini-docs.toss.im/tds-react-native/components/dialog/) | [Dialog](../components.html#dialog) | Default |
| [Dropdown](https://tossmini-docs.toss.im/tds-react-native/components/dropdown/) | [ActionMenu](../components.html#action-menu) | Default |
| [Error Page](https://tossmini-docs.toss.im/tds-react-native/components/error-page/) | [Result](../components.html#result) | Default |
| [Gradient](https://tossmini-docs.toss.im/tds-react-native/components/gradient/) | [Gradient](../components.html#gradient) | Default |
| [Grid List](https://tossmini-docs.toss.im/tds-react-native/components/grid-list/) | [GridList](../components.html#grid-list) | Default |
| [Highlight](https://tossmini-docs.toss.im/tds-react-native/components/highlight/) | [Highlight](../components.html#highlight) | Default |
| [Icon Button](https://tossmini-docs.toss.im/tds-react-native/components/icon-button/) | [IconButton](../components.html#icon-button) | Default |
| [Keypad](https://tossmini-docs.toss.im/tds-react-native/components/keypad/) | [Keypad](../components.html#keypad) | Default |
| [List](https://tossmini-docs.toss.im/tds-react-native/components/list/) | [List](../components.html#list) | Default |
| [List Footer](https://tossmini-docs.toss.im/tds-react-native/components/list-footer/) | [ListFooter](../components.html#list-footer) | Default |
| [List Header](https://tossmini-docs.toss.im/tds-react-native/components/list-header/) | [ListHeader](../components.html#list-header) | Default |
| [List Row](https://tossmini-docs.toss.im/tds-react-native/components/list-row/) | [ListRow](../components.html#list-row) | Default |
| [Loader](https://tossmini-docs.toss.im/tds-react-native/components/loader/) | [Spinner](../components.html#spinner) | Default |
| [Navbar](https://tossmini-docs.toss.im/tds-react-native/components/navbar/) | [Navbar](../components.html#navbar) | Default |
| [Numeric Spinner](https://tossmini-docs.toss.im/tds-react-native/components/numeric-spinner/) | [NumericSpinner](../components.html#numeric-spinner) | Default |
| [Post](https://tossmini-docs.toss.im/tds-react-native/components/post/) | [Post](../components.html#post) | Default |
| [Progress Bar](https://tossmini-docs.toss.im/tds-react-native/components/progress-bar/) | [Progress](../components.html#progress) | Default |
| [Radio](https://tossmini-docs.toss.im/tds-react-native/components/radio/) | [RadioGroup](../components.html#radio-group) | Default |
| [Rating](https://tossmini-docs.toss.im/tds-react-native/components/rating/) | [Rating](../components.html#rating) | Default |
| [Result](https://tossmini-docs.toss.im/tds-react-native/components/result/) | [Result](../components.html#result) | Default |
| [Search Field](https://tossmini-docs.toss.im/tds-react-native/components/search-field/) | [SearchField](../components.html#search-field) | Default |
| [Segmented Control](https://tossmini-docs.toss.im/tds-react-native/components/segmented-control/) | [SegmentedControl](../components.html#segmented-control) | Default |
| [Shadow](https://tossmini-docs.toss.im/tds-react-native/components/shadow/) | [Elevation](../components.html#elevation) | Default |
| [Skeleton](https://tossmini-docs.toss.im/tds-react-native/components/skeleton/) | [Skeleton](../components.html#skeleton) | Default |
| [Slider](https://tossmini-docs.toss.im/tds-react-native/components/slider/) | [Slider](../components.html#slider) | Default |
| [Stepper](https://tossmini-docs.toss.im/tds-react-native/components/stepper/) | [Stepper](../components.html#stepper) | Default |
| [Switch](https://tossmini-docs.toss.im/tds-react-native/components/switch/) | [Switch](../components.html#switch) | Default |
| [Tab](https://tossmini-docs.toss.im/tds-react-native/components/tab/) | [Tabs](../components.html#tabs) | Default |
| [Table Row](https://tossmini-docs.toss.im/tds-react-native/components/table-row/) | [TableRow](../components.html#table-row) | Default |
| [Text Button](https://tossmini-docs.toss.im/tds-react-native/components/text-button/) | [Button](../components.html#button) | quiet |
| [Text Field](https://tossmini-docs.toss.im/tds-react-native/components/text-field/) | [TextField](../components.html#text-field) | Default |
| [Toast](https://tossmini-docs.toss.im/tds-react-native/components/toast/) | [Toast](../components.html#toast) | Default |
| [Bar Chart](https://tossmini-docs.toss.im/tds-react-native/components/Chart/bar-chart/) | [BarChart](../components.html#bar-chart) | Default |
