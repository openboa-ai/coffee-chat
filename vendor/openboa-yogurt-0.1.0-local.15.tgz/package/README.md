# yogurt

[Component SDK](components.html) · [Brand, tokens and product language](components.html#brand) · [Install on web or Zig](docs/using-yogurt.md)

ships with live cultures

This kit carries OpenBoa’s identity into the next product. Open the [brand guide](index.html), [design system](system.html), [editable sources](library.html), [research](research.html) or [project adoption guide](adoption.html) in a browser. The kit works offline.

| When you need to… | Start here |
| --- | --- |
| Introduce the company or credit a project | [Home and About copy](index.html#identity) · [Company, project and agent names](index.html#family) |
| Write a repository description, action or recovery message | [Voice and examples](index.html#voice) · [Machine-readable English terms](content/terms.json) |
| Choose and place a logo | [Three masters and a worked header](index.html#logo) · [Download artwork](index.html#files) |
| Choose a type role or a legible color pair | [Type scale](system.html#type) · [Shared palette and contrast](system.html#color) |
| Find a general emoji for a message or product | [Search 3,831 emoji](emoji.html) · [SVGs, PNGs and credits](assets/emoji/README.md) |
| Identify a project in a message or release note | [The three food emoji](library.html#emoji) · [Editable paths and palette references](assets/projects/emoji.json) |
| Start from artwork, a chart, a face or a motion study | [Editable source library](library.html) · [Purpose and original references](research.html) |
| Turn a product intent into an interface | [Product playbook](playbook.html) · [Agent entry](DESIGN.md) · [Repository blueprint](docs/repository.md) |
| Build a screen | [125 components](components.html) · [Workspace patterns](docs/workspace-patterns.md) · [Install editable blocks](docs/using-yogurt.md#editable-blocks) |
| Adopt yogurt across a project and reference it in intents | [Proposed project binding](adoption.html#setup) · [Worked intent](adoption.html#intent) · [Release and upgrade model](adoption.html#releases) |

[Compose a project sidebar](docs/sidebar.md) from shared navigation parts.

## Design records

The [design handbook](docs/index.html) brings the visual direction, component foundation, craft standard and design portfolio into one offline reader. The [canonical Markdown records](docs/README.md) connect each intent to its design and engineering changes.

Start component review with [four controls in a saved view](studies/basic-controls/index.html). Each has an [intent, paired spec and acceptance scene](docs/engineering/controls/first-four/README.md).

## Use the resources

The [horizontal signature](assets/logo/openboa-lockup.svg) pairs the original Upright 9 symbol and outlined Rethink Sans 760 wordmark at the selected B2 proportions. The [weight study](studies/signature/index.html) records that choice. OpenBoa’s primary color is Ink blue, `slate.750` (#175174), taken from the Upright 9 master.

App clients use [Vercel Native SDK as their default stack](docs/native-stack.md). For the web, [components.css](styles/components.css) imports the bundled fonts and generated tokens. For a native client, start with the [token JSON](tokens/brand.json), [upright TTF](assets/fonts/rethink-sans/rethink-sans.ttf), [italic TTF](assets/fonts/rethink-sans/rethink-sans-italic.ttf) and [outlined masters](index.html#files). Platform components, package distribution and automated consumer checks are described in the [adoption proposal](adoption.html).

Edit the token JSON and run `node scripts/export-css.mjs` from this directory to regenerate the [CSS variables](styles/tokens.css). Keep the JSON and the generated file together.

Rethink Sans v1.001 ships under the SIL Open Font License 1.1. Preserve the notice with redistributed fonts. [Font source](https://github.com/hans-thiessen/Rethink-Sans/tree/20d5980cd14ce827e82d7fc58d758f7cc5086c91) · [Included license](assets/fonts/rethink-sans/OFL.txt)

Project emoji use named values from the same palette. Edit the paths or token names in [emoji.json](assets/projects/emoji.json) and run `node scripts/export-emoji.mjs` to regenerate the three SVGs. Rasterize each SVG on transparency at 128 × 128 for its chat PNG.
